# Upgrade Plan: test-scheduling-backend (20260508080215)

- **Generated**: 2026-05-08 08:02:15
- **HEAD Branch**: N/A
- **HEAD Commit ID**: N/A

## Available Tools

**JDKs**
- JDK 17: not available (baseline will be skipped)
- JDK 25: /Library/Java/JavaVirtualMachines/temurin-25.jdk/Contents/Home/bin (current project JDK)

**Build Tools**
- Maven 3.9.15: /opt/homebrew/Cellar/maven/3.9.15/bin → **<TO_BE_UPGRADED>** to 4.0+ (current version incompatible with Java 25)

## Guidelines

> Note: You can add any specific guidelines or constraints for the upgrade process here if needed, bullet points are preferred.

## Options

- Working branch: appmod/java-upgrade-20260508080215
- Run tests before and after the upgrade: true

## Upgrade Goals

- Upgrade Java runtime to version 25

## Technology Stack

| Technology/Dependency    | Current | Min Compatible Version | Why Incompatible                               |
| ------------------------ | ------- | -------------- | ---------------------------------------------- |
| Java                     | 17       | 25             | User requested                                 |
| Spring Boot              | 3.2.10   | 4.0.0          | Spring Boot 4.x required for Java 25 support  |
| Maven                    | 3.9.15   | 4.0.0          | Maven 4.0+ required for Java 25                |
| maven-compiler-plugin    | 3.11.0   | 3.11.0         | -                                              |
| Lombok                   | 1.18.38 | 1.18.38        | -                                              |
| JJWT                     | 0.12.6  | 0.13.0         | JJWT 0.13.x required for Jakarta EE support   |
| MySQL Connector          | 8.4.0   | 8.4.0          | -                                              |
| H2                       | 2.2.224 | 2.2.224        | -                                              |

## Derived Upgrades

- Upgrade Spring Boot from 3.2.10 to 4.0.0+ for Java 25 compatibility
- Upgrade Maven from 3.9.15 to 4.0+ for Java 25 support
- Upgrade JJWT from 0.12.6 to 0.13.0+ for Jakarta EE namespace compatibility
- Update maven-compiler-plugin to latest version compatible with Java 25

## Upgrade Steps

- Step 1: Setup Environment
  - **Rationale**: Install required build tools for Java 25 compatibility
  - **Changes to Make**: Install Maven 4.0+
  - **Verification**: Command: mvn --version, JDK: N/A, Expected Result: Maven 4.0+ installed and available
- Step 2: Setup Baseline
  - **Rationale**: Establish baseline compilation and test results (skipped due to unavailable base JDK)
  - **Changes to Make**: None
  - **Verification**: Command: N/A, JDK: N/A, Expected Result: Skipped
- Step 3: Upgrade Dependencies and Apply Jakarta Migration
  - **Rationale**: Upgrade Spring Boot to 4.x and related dependencies, migrate from javax to jakarta namespaces
  - **Changes to Make**: Update pom.xml: Spring Boot version to 4.0.0, JJWT to 0.13.0; Apply OpenRewrite Jakarta migration recipe
  - **Verification**: Command: mvn clean test-compile -q, JDK: 25, Expected Result: Compilation succeeds
- Step 4: Upgrade Java Version
  - **Rationale**: Update project to use Java 25
  - **Changes to Make**: Update pom.xml java.version to 25
  - **Verification**: Command: mvn clean test-compile -q, JDK: 25, Expected Result: Compilation succeeds
- Step 5: Final Validation
  - **Rationale**: Verify all upgrades successful, all TODOs resolved, full test suite passes
  - **Changes to Make**: Clean rebuild, run tests, resolve any remaining issues
  - **Verification**: Command: mvn clean test -q, JDK: 25, Expected Result: Compilation and all tests pass

## Key Challenges

- **Jakarta EE Namespace Migration**
   - **Challenge**: Codebase uses javax.* packages that must migrate to jakarta.* in Spring Boot 4.x.
   - **Strategy**: Use OpenRewrite migration recipes after Spring Boot upgrade.</content>
<parameter name="filePath">/Users/mac/Desktop/code/ceshi-v1.0/backend/.github/java-upgrade/20260508080215/plan.md