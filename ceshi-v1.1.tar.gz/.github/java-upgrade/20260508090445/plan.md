# Upgrade Plan: test-scheduling-backend (20260508090445)

- **Generated**: 2026-05-08 09:04:45
- **HEAD Branch**: appmod/java-upgrade-20260508080215
- **HEAD Commit ID**: To be determined after branch setup

## Available Tools

**JDKs**
- JDK 17: /Library/Java/JavaVirtualMachines (current project JDK, used for baseline)
- JDK 25: /Library/Java/JavaVirtualMachines/temurin-25.jdk/Contents/Home (available for target)
- JDK 25: /opt/homebrew/Cellar/openjdk/25.0.2/libexec/openjdk.jdk/Contents/Home (alternative)

**Build Tools**
- Maven 3.9.15: /opt/homebrew/Cellar/maven/3.9.15/bin (compatible with Java 25)

## Guidelines

> Note: You can add any specific guidelines or constraints for the upgrade process here if needed, bullet points are preferred.

## Options

- Working branch: appmod/java-upgrade-20260508090445
- Run tests before and after the upgrade: true

## Upgrade Goals

- **Java Runtime**: Upgrade from Java 17 to Java 25 (latest LTS)

## Technology Stack

| Technology/Dependency    | Current | Min Compatible for Java 25 | Why Incompatible                                        |
| ------------------------ | ------- | -------------------------- | ------------------------------------------------------- |
| Java                     | 17      | 25                         | User requested - upgrade to latest LTS version         |
| Spring Boot              | 3.2.10  | 3.4.0+                     | 3.2.x pre-dates Java 25; 3.4.x+ provides full support |
| Maven                    | 3.9.15  | 3.9.0+                     | Already compatible with Java 25                        |
| Maven Compiler Plugin    | 3.11.0  | 3.11.0+                    | Inherited from Spring Boot parent; supports Java 25    |
| MySQL Connector          | 8.4.0   | 8.4.0+                     | Already compatible                                     |
| Lombok                   | 1.18.38 | 1.18.38+                   | Already compatible                                     |
| JJWT (JWT)               | 0.12.6  | 0.12.6+                    | Already compatible                                     |

## Derived Upgrades

- **Spring Boot 3.2.10 → 3.4.0+**: Spring Boot 3.4 introduces explicit Java 25 compatibility and continued LTS timeline alignment. 3.2.x was released before Java 25 and may encounter compatibility edge cases. Intermediate to 3.3.x not needed; direct upgrade is feasible.

## Upgrade Steps

- **Step 1: Setup Environment**
  - **Rationale**: Ensure JDK 25 is available for compilation and testing during the upgrade process.
  - **Changes to Make**: 
    - Verify JDK 25 installation and availability
    - Confirm Maven 3.9.15 is available in PATH
  - **Verification**: `java -version` returns 25.x.x; `mvn -version` returns Maven 3.9.15+

- **Step 2: Setup Baseline**
  - **Rationale**: Establish baseline compilation and test pass rates with current Java 17 and Spring Boot 3.2.10 before making any changes.
  - **Changes to Make**:
    - Compile codebase with Java 17
    - Run full test suite
    - Document results for comparison
  - **Verification**: `mvn clean compile test-compile -q` succeeds; `mvn clean test -q` runs without errors; record test pass rate and total count

- **Step 3: Upgrade Spring Boot to 3.4.0**
  - **Rationale**: Spring Boot 3.4.0 is the first release with explicit Java 25 compatibility and support. This is a prerequisite for Java 25 upgrade.
  - **Changes to Make**:
    - Update `<version>3.4.0</version>` in parent pom.xml
    - Review and resolve any dependency version conflicts in pom.xml
    - Verify no breaking API changes affecting the application code
  - **Verification**: `mvn clean test-compile -q` (with Java 17) compiles successfully; no compilation errors

- **Step 4: Update Java Version to 25**
  - **Rationale**: Update the project's target Java version to 25 after Spring Boot compatibility is ensured.
  - **Changes to Make**:
    - Update `<java.version>25</java.version>` in pom.xml
    - Rebuild with Java 25
  - **Verification**: `mvn clean test-compile -q` (with Java 25) compiles successfully; both main and test code compile without errors

- **Step 5: Final Validation**
  - **Rationale**: Comprehensive verification that the upgrade is complete and stable. Resolve any test failures through iterative fix cycles.
  - **Changes to Make**:
    - Run full test suite with Java 25
    - Fix any test failures
    - Verify no runtime compatibility issues
    - Clean up any TODO comments added during upgrade
  - **Verification**: `mvn clean test -q` (with Java 25) passes 100% of tests; compare pass rate with baseline; all production and test code compiles successfully

## Key Challenges

- **Spring Boot Version Boundary**: Spring Boot 3.2.x predates Java 25 release. Upgrade to 3.4.x required for full compatibility and LTS alignment.
- **Dependency Compatibility**: Most dependencies (MySQL Connector, Lombok, JJWT) are forward-compatible. No major compatibility issues anticipated.
- **No Known Source Code Issues**: Project code does not use deprecated or removed Java APIs (e.g., `setAccessible`, `sun.misc.*`, `Thread.stop()`, etc.). Compilation and runtime should proceed smoothly.
